import React from "react";

export default function Profile() {
  return (
    <section className="pageCard">
      <h1>Profile</h1>
      <p>Template profile page. Render user data from Django here later.</p>
    </section>
  );
}
