# Sustainability Shell (React + Vite)

This project matches your requested layout:
- Top header
- Left nav (collapsible)
- Right auth panel (collapsible, lock icon)
- Footer
- Center React Router routes (Home/About/Profile)

## Run
```bash
npm install
npm run dev
```

## Notes
- Replace Django auth endpoints in: `src/layout/RightAuthPanel.jsx`
- Background image is currently a remote URL in `src/App.js`. Swap it anytime.
