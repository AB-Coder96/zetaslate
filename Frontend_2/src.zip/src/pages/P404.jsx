import React from "react";

export default function About() {
  return (
    <section className="pageCard">
      <h1>Not Found</h1>
    </section>
  );
}
