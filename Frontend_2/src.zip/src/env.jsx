// Hardcoded app config (single source of truth)
export const API_BASE = "https://api.core.zetaslate.com";