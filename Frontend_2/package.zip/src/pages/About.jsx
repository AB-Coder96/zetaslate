import React from "react";

export default function About() {
  return (
    <section className="pageCard">
      <h1>About</h1>
      <p>Template page. Replace with your sustainability portfolio content.</p>
    </section>
  );
}
